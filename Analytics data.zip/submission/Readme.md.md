========================================== Setup Environment
========================================== pip install -r
requirements.txt

========================================== Run steamlit app
========================================== streamlit run dashboard.py
